module.exports = {
  BOT_TOKEN: "8098551444:AAHUSA4ftj63Zbv1IW7vJm9EOzUe0dvJIFU",
    allowedDevelopers: ['8146204602'], // ID
};